import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

class Mobile {
String countryCode,mobileNo;
Query dataBase=new Query();
Mobile(String a,String b)
{
	countryCode=a;
	mobileNo=b;
}
public static void main(String args[]) throws SQLException{
	Query q=new Query();
	ResultSet rs=q.Execute("select country from Countrycode where code =?","00");
	System.out.println(rs.getString("country"));
}
String getCountry()throws SQLException
{
	ResultSet rs=dataBase.Execute("select country from Countrycode where code=? ", countryCode);
	if(rs.next())
	return rs.getString("country");
	else return "Undefined";
}
String getOperatorCode() throws SQLException
{
	ResultSet rs=dataBase.Execute("select * from Mobileno where mobile =? ", mobileNo.substring(0,4));
	if(rs.next())
	return rs.getString("operator");
	else return "Undefined";
}
String getOperator() throws SQLException
{
	ResultSet rs=dataBase.Execute("select * from Mobileno where mobile =? ", mobileNo.substring(0,4));
	if(rs.next())
	{
		String operator=rs.getString("operator");
		rs=dataBase.Execute("select Net from Operator where opp =? ", operator);
		if(rs.next())
		return rs.getString("Net");	//Valid Operator Code
		else return "Undefined";	//Invalid Operator Code
	}
	else return "Undefined";	//Operator Not Available
}
String getState() throws SQLException
{
	ResultSet rs=dataBase.Execute("select * from Mobileno where mobile=?",mobileNo.substring(0,4));
	if(rs.next())
	{
		String state=rs.getString("state");
		rs=dataBase.Execute("select state from State where stcode =? ", state);
		if(rs.next())
		return rs.getString("state");	//Valid State Code
		else return "Undefined";	//Invalid State Code
	}
	else return "Undefined";		//State not Available
}
public void getnetpics(JLabel oprpics,JLabel net,JLabel operatorlabel) throws SQLException
{
	String netopr=getOperator();
	Image oprpic;
	if(netopr.equals("Bharti Airtel"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/airtel2.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Vodafone India"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Vodafone.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Reliance Mobile CDMA")||netopr.equals("Reliance Mobile GSM"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Reliance.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("MTS India"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/mts3.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("BSNL - CellOne CDMA")||netopr.equals("BSNL - CellOne GSM"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/BSNL2.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Reliance Jio Infocomm"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/jio.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Videocon Mobile Services"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/videocon2.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("TATA DOCOMO"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/docomo.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("AIRCEL"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/aircel.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Tata Indicom"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/tataindicom.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("IDEA"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Idea.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Telenor"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Telenor.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Virgin Mobile India CDMA")||netopr.equals("Virgin Mobile India GSM"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/VirginMobile.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Vodafone India"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Vodafone.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("T24 (BIG BAZAAR)"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/T24.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("S Tel"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/STel.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Spice Digital"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Spice.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("PING CDMA (HFCL Infotel Ltd.)"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/ping.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Loop Mobile"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/Loop.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("MTNL - DOLPHIN"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/mtnl.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else if(netopr.equals("Etisalat India (Getting into the market as Cheers Mobile)"))
	{
		oprpic= new ImageIcon(this.getClass().getResource("/etisalat.png")).getImage();
		oprpics.setIcon(new ImageIcon(oprpic));
		net.setVisible(false);
        operatorlabel.setVisible(false);
		oprpics.setVisible(true);
				
	}
	else
	{
		net.setVisible(true);
		net.setText(netopr);
		oprpics.setVisible(false);
	}
}
}
class Query{
	Connection conn;
	Query(){
		conn=Dataconnect.dbConnector();;
	}
	ResultSet Execute(String query,String value) throws SQLException
	{
		PreparedStatement pst;
		pst=conn.prepareStatement(query);
		pst.setString(1, value);
		return pst.executeQuery();
	}
}
