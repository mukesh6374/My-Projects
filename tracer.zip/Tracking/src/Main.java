import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class Main {

	private JFrame frame;
	private java.awt.Image img,imgg,img2,img3,img4,img6,img5,img7;
	private JTextField cc,Mbno;
	private JButton refbtn;//Tracebtn;
	private boolean flagmb=true,flagcc=true;
	String code="", mobileno="";
	private JLabel mobilelabel,cclabel,operatorlabel,countrylabel;
	private JLabel Locationlabel,world;
	private JLabel netlabel;
	private JLabel reflabel;
	private JLabel statelabel;
	private JLabel locs,net,loc,oprpics;
	private JLabel ccstar;
	private JLabel mbstar;
	boolean flag=false;

	/**
	 * Launch the application.
	 */
	public void refresh()
	{
		Mbno.setText("10 Digit Mb no.");
		cc.setText("91");
		net.setText("");
		loc.setText("");
		locs.setText("");
		ccstar.setText("");
		mbstar.setText("");
		flagmb=true;
		flagcc=true;
		net.setVisible(false);
		loc.setVisible(false);
		operatorlabel.setVisible(false);
		countrylabel.setVisible(false);
		Locationlabel.setVisible(false);
		netlabel.setVisible(false);
		locs.setVisible(false);
		statelabel.setVisible(false);
		world.setVisible(true);
		cc.setForeground(Color.GRAY);
		Mbno.setForeground(Color.GRAY);
		invisible();
	}
	public void visible()
	{
		net.setVisible(true);
		loc.setVisible(true);
		operatorlabel.setVisible(true);
		countrylabel.setVisible(true);
		Locationlabel.setVisible(true);
		netlabel.setVisible(true);
		locs.setVisible(true);
		statelabel.setVisible(true);
	}
	public void invisible()
	{
		net.setVisible(false);
		loc.setVisible(false);
		operatorlabel.setVisible(false);
		countrylabel.setVisible(false);
		Locationlabel.setVisible(false);
		netlabel.setVisible(false);
		locs.setVisible(false);
		statelabel.setVisible(false);
		world.setVisible(true);
		oprpics.setVisible(false);
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
		refresh();
		//Mbno.setRequestFocusEnabled(true);
		Mbno.requestFocusInWindow();
	}
	private void initialize() {
		frame = new JFrame("Tracer");
		frame.setBounds(100, 100, 864, 496);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(0,114,198));
		//Main Title
		JLabel Title = DefaultComponentFactory.getInstance().createLabel("MOBILE TRACKING SYSTEM");
		Title.setHorizontalAlignment(SwingConstants.CENTER);
		Title.setBackground(Color.GRAY);
		Title.setForeground(Color.WHITE);
		Title.setFont(new Font("Microsoft Himalaya", Font.PLAIN, 32));
		Title.setBounds(119, 27, 545, 58);
		frame.getContentPane().add(Title);
		//JTextfield for entering country code starting
		img = new ImageIcon(this.getClass().getResource("/cc.png")).getImage();
		cc = new JTextField(3);
		cc.setForeground(Color.GRAY);
		cc.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed (KeyEvent arg0) {
				if(arg0.getKeyCode()==KeyEvent.VK_ENTER)
					{updateData();
					return;
					}
				invisible();
			    if(Mbno.getText().length()<10){
					Mbno.setText("10 Digit Mb no.");
					flagmb=true;
					Mbno.setForeground(Color.GRAY);
				}
				if(flagcc)
				{
					cc.setText("");
					flagcc=false;
					cc.setForeground(Color.BLACK);
				}
			}
		});
		cc.setText("91");
		cc.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 14));
		cc.setHorizontalAlignment(SwingConstants.CENTER);
		cc.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		cc.setBackground(Color.BLUE);
		frame.getContentPane().add(cc);
		cc.setOpaque( false );
		cc.setBounds(144, 106, 39, 39);
		cc.setColumns(10);
		cclabel = new JLabel("");
		cclabel.setIcon(new ImageIcon(img));
		cclabel.setBounds(119, 104, 114, 50);
		frame.getContentPane().add(cclabel);
		cclabel.setLayout( new BorderLayout());
		
		ccstar = new JLabel("");
		ccstar.setForeground(Color.RED);
		ccstar.setBounds(130, 147, 77, 14);
		frame.getContentPane().add(ccstar);
		//JTextfield for entering country code ending
		
		//JTextfield for entering mobile no. starting
		img = new ImageIcon(this.getClass().getResource("/mobile.png")).getImage();
		Mbno = new JTextField("10 Digit Mb no.");
		
		Mbno.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed (KeyEvent arg0) {
				if(arg0.getKeyCode()==KeyEvent.VK_ENTER)
					{updateData();
					return;
					}
				invisible();
				 if(cc.getText().length()==0)
					{
						cc.setText("91");
						flagcc=true;
						invisible();
						cc.setForeground(Color.GRAY);
					}
				if(flagmb)
				{
					Mbno.setText("");
					flagmb=false;
					Mbno.setForeground(Color.BLACK);
				}
			}
		});	
/*		Mbno.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				updateData();
				
			}
		});*/
		Mbno.setForeground(Color.GRAY);
		Mbno.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 14));
		Mbno.setHorizontalAlignment(SwingConstants.CENTER);
		Mbno.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		Mbno.setBackground(Color.BLUE);
		frame.getContentPane().add(Mbno);
		Mbno.setOpaque( false );
		Mbno.setBounds(198, 110, 125, 30);
		Mbno.setColumns(10);
		
		mbstar = new JLabel("");
		mbstar.setForeground(Color.RED);
		mbstar.setBounds(243, 147, 87, 14);
		frame.getContentPane().add(mbstar);
		
		imgg = new ImageIcon(this.getClass().getResource("/mbnet.png")).getImage();
//JTextfield for Network operator ending
		
//JTextfield for location starting
		
		Locationlabel = new JLabel("Location:");
		Locationlabel.setForeground(Color.WHITE);
		Locationlabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		Locationlabel.setBounds(425, 199, 96, 50);
		frame.getContentPane().add(Locationlabel);	

		img2 = new ImageIcon(this.getClass().getResource("/loc.png")).getImage();
		loc = new JLabel();
		frame.getContentPane().add(loc);
		loc.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 19));
		loc.setHorizontalAlignment(SwingConstants.CENTER);
		loc.setBorder(javax.swing.BorderFactory.createEmptyBorder());
	

		loc.setOpaque( false );
		loc.setBounds(508, 207, 297, 30);		
		countrylabel = new JLabel("");
		countrylabel.setIcon(new ImageIcon(img2));
		countrylabel.setBounds(472, 199, 351, 50);
		frame.getContentPane().add(countrylabel);
		countrylabel.setLayout( new BorderLayout());
		
        img6 = new ImageIcon(this.getClass().getResource("/loc.png")).getImage();
		locs = new JLabel();
		locs.setHorizontalAlignment(SwingConstants.CENTER);
		locs.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));
		locs.setOpaque(false);
		locs.setBounds(508, 246, 301, 39);
		frame.getContentPane().add(locs);
		locs.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		
		statelabel = new JLabel("");
		statelabel.setIcon(new ImageIcon(img6));
		statelabel.setBounds(474, 240, 349, 56);
		frame.getContentPane().add(statelabel);
		statelabel.setLayout(new BorderLayout());
		//JTextfield for Location ending
				
		refbtn = new JButton("Refresh");
		refbtn.setForeground(Color.WHITE);
		//img = new ImageIcon(this.getClass().getResource("/refresh.png")).getImage();
		//refbtn.setIcon(new ImageIcon(img));
		refbtn.setOpaque(false);
		refbtn.setContentAreaFilled(false);
		refbtn.setBorderPainted(false);
		refbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refresh();
			}
		});
		refbtn.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 16));
		refbtn.setBounds(37, 165, 146, 39);
		frame.getContentPane().add(refbtn);
		
		JButton Tracebtn = new JButton("Trace");
		Tracebtn.setForeground(Color.WHITE);
		Tracebtn.setOpaque(false);
		Tracebtn.setContentAreaFilled(false);
		Tracebtn.setBorderPainted(false);
		Tracebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					updateData();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		
		Tracebtn.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 16));
		Tracebtn.setBounds(198, 165, 146, 39);
		frame.getContentPane().add(Tracebtn);
		
		JLabel entermb = new JLabel("Enter Number:    +           -");
		entermb.setForeground(Color.WHITE);
		entermb.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 16));
		entermb.setBounds(16, 114, 224, 23);
		frame.getContentPane().add(entermb);
		
		img3 = new ImageIcon(this.getClass().getResource("/mbtrace.png")).getImage();
		
		JLabel tracelabel = new JLabel("");
		tracelabel.setIcon(new ImageIcon(img3));
		tracelabel.setBounds(154, 156, 195, 65);
		frame.getContentPane().add(tracelabel);
		tracelabel.setLayout(new BorderLayout());
		
		img4 = new ImageIcon(this.getClass().getResource("/mbref.png")).getImage();
		reflabel = new JLabel("");
		reflabel.setIcon(new ImageIcon(img4));
		reflabel.setBounds(-6, 156, 189, 65);
		frame.getContentPane().add(reflabel);

		mobilelabel = new JLabel("");
		mobilelabel.setIcon(new ImageIcon(img));
		mobilelabel.setBounds(132, 102, 212, 50);
		frame.getContentPane().add(mobilelabel);
		mobilelabel.setLayout( new BorderLayout());
		
		img5 = new ImageIcon(this.getClass().getResource("/connect.gif")).getImage();
		
		img7= new ImageIcon(this.getClass().getResource("/footer.png")).getImage();
		JLabel footer = new JLabel("");
		footer.setFont(new Font("Tahoma", Font.BOLD, 11));
		footer.setIcon(new ImageIcon(img7));
		footer.setHorizontalAlignment(SwingConstants.CENTER);
		footer.setBounds(-6, 442, 896, 16);
		//frame.getContentPane().add(footer);
		
		//JTextfield for entering mobile no. ending
		
		
		//JTextfield for Network Operator starting
	
		oprpics = new JLabel("");
		oprpics.setBounds(572, 72, 231, 115);
		frame.getContentPane().add(oprpics);
				
		netlabel = new JLabel("Network Operator:");
		netlabel.setForeground(Color.WHITE);
		netlabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		netlabel.setBounds(425, 100, 153, 50);
		frame.getContentPane().add(netlabel);
		net = new JLabel();
		frame.getContentPane().add(net);
		net.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));
		net.setHorizontalAlignment(SwingConstants.CENTER);
		net.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		net.setBackground(Color.BLUE);
		//frame.getContentPane().add(net);
		net.setOpaque( false );
		net.setBounds(572, 106, 224, 39);
		
		operatorlabel = new JLabel("");
		operatorlabel.setIcon(new ImageIcon(imgg));
		operatorlabel.setBounds(493, 104, 317, 50);
		frame.getContentPane().add(operatorlabel);
		operatorlabel.setLayout( new BorderLayout());
		world = new JLabel("");
		world.setIcon(new ImageIcon(img5));
		world.setBounds(406, 85, 417, 271);
		frame.getContentPane().add(world);
		//frame.getRootPane().setDefaultButton(Tracebtn);
		new ImageIcon(this.getClass().getResource("/antenna.png")).getImage();
	}
	public void updateData() 	//Function Which update Data
	{
		String code=cc.getText();
		String mobileNo=Mbno.getText();
		int cclen=code.length();
		int mblen=mobileNo.length();
		String country="Undefined",state="Undefined";
		boolean isvalid=true;
		if(cclen<1||cclen>3 ||mblen<10 ||mblen>10)
		{
			 if(cclen>3)
			    {ccstar.setText("Invalid");
			    isvalid=false;
			    }
			 if(mblen<10 ||mblen>10)
				{mbstar.setText("Invalid");
				isvalid=false;
				}
			 if(cclen==0)code="91";
		}
		if(!isvalid){
			net.setText("");
			loc.setText("");
			locs.setText("");
			return;
		}
		Mobile M=new Mobile(code,mobileNo);
		try{
			country=M.getCountry();
			if(country.equals("India")&&mblen==10)
			{
				state=M.getState();
				//operator=M.getOperator();
				visible();
				M.getnetpics(oprpics,net,operatorlabel);
			}
			else if(!country.equals("India"))
			{
				visible();
				net.setText("Undefined");
				net.setVisible(true);
				loc.setText(country);
				locs.setText("Undefined");
				
			}
		}catch(SQLException e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
		ccstar.setText("");
		mbstar.setText("");
		world.setVisible(false);
		//net.setText(operator);
		loc.setText(country);
		locs.setText(state);
	}
}
