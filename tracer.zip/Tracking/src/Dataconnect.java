import java.sql.*;

import javax.swing.*;
public class Dataconnect {
	
	Connection conn=null;
	public static Connection dbConnector() {
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection conn = DriverManager.getConnection("jdbc:sqlite::resource:mobile.sqlite");
			//System.out.println(conn.getMetaData().getTables(null, null, null, null).getString(10));
			//JOptionPane.showMessageDialog(null,conn);
			//System.out.println(conn.getSchema());
			return conn;
			
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
			
			return null;	
		}
	}

}
