import java.sql.SQLException;
/*
 * This class is used for debugging Purposes only
 */
public class Test {
	public static void main(String args[]) throws SQLException{
	Mobile m=new Mobile("91","9798331073");
	System.out.println(m.getCountry());
	  System.out.println(m.getOperator());
	  System.out.println(m.getState());
	}

}
